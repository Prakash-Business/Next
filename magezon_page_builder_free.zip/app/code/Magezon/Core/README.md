# Magezon Core extension for Magento 2
Content is coming soon.